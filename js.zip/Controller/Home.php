<?php


namespace Classes;


class Home
{
    function getHTML(){

    }
}