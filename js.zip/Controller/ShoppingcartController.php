<?php
namespace Controller;

use Model\ShoppingCart;

Class ShoppingcartController
{
 private $shoppingcart;
 function __construct()
 {
 }
 private  function test()
 {

 }
}