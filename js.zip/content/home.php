<?php

include_once 'content/header.php';
<<<<<<< HEAD

<<<<<<< HEAD
=======

>>>>>>> b2bb1f4d544f81dcbbf97a44c468f2323b034549
=======
$database = new Model\Database();
>>>>>>> 71dba54fefa3d93c63c778db6fcc7195b5a115b2
?>

    <div class="container">
        <div class="adv">

        </div>

        <div class = "info">
            <h2>Oma's beste</h2><br>

            <h5>Producten zoals oma ze vroeger maakte!</h5>

            <p1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p1>
        </div>
    </div>
<?php

include_once 'content/footer.php';

?>