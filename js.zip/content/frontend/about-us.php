<?php

include_once 'loader.php';

?>

<div>
    <div id="Content">
        <?php $mainController->showContent( "TITLE");?>
    </div>
</div>
<?php

include_once 'content/footer.php';

?>
