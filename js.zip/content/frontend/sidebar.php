<div class="wrapper">
<div class="sidenav">


    <?php
    echo $mainController->nav_menu_side_fe();
    ?>

</div>
