                <div class="row">
                <footer>
                    <small>&copy;<?php echo date('Y'); ?> <?php echo $mainController->site_name(); ?>.<br><?php echo $mainController->site_version(); ?></small>
                </footer>

            </div>
        </div>
    </div>
</body>
    <script src="..\scripts\script.js"></script>
</html>