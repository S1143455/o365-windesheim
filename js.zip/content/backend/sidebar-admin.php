<div class="col-md-2">
    <div class="sidenav">
        <?php echo $admin->nav_menu_side(); ?>
    </div>
</div>