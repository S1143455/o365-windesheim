</div>
<div class="container">
    <div class="row">
      <footer>
            <small>&copy;<?php echo date('Y'); ?> <?php echo $mainController->site_name(); ?>.<br><?php echo $mainController->site_version(); ?></small>
        </footer>

    </div>
</div>
    <script type="text/javascript" src="../js/script.js"></script>
</body>
</html>