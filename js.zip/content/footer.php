    <div class="row">
    <footer>
        cxxx
        <small>&copy;<?php echo date('Y'); ?> <?php echo $mainController->site_name(); ?>.<br><?php echo $mainController->site_version(); ?></small>
    </footer>

</div>
    </div>
</body>
</html>