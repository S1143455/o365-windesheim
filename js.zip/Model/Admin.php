<?php


namespace Model;


class Admin extends User
{

}