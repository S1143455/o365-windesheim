<?php


namespace Model;


class ShoppingCart
{

}