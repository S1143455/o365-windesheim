<?php
echo "Delete page";