<?php
echo "show page";