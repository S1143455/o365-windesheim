<?php

foreach ($products as $product)
{
    echo $product->getStockItemID();
}





