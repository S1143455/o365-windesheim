<?php
echo 'show.php';