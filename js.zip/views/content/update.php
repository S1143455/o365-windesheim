<?php
echo 'update.php';