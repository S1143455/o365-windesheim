<?php
echo 'index.php';